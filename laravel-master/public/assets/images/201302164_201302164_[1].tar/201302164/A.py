import random
from maze import *
from random import randrange
score = 0
ghost_count=0
flag=0
#coins_counter=1
move = 'x'
p=q=r=s=0


ghost_x = [0 for x in xrange(100)]
ghost_y = [0 for x in xrange(100)] 
ghost_instance = [0 for x in xrange(100)]

maze()
maze()

	
def make_pac():
	x=17
	y=25
	for i in xrange(1,49):
		Matrix[17][i]="."
	Matrix[x][y]='P'

make_pac()
class bcolors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'




def check_wall(p,q):
	if Matrix[p][q] == 'X':
		return True
	else :
		return False
def check_ghost(p,q):
	if Matrix[p][q]=="G" :
		return True
	else:
		return False
def check_pacman(p,q):
	if Matrix[p][q]=="P" :
		return True
	else:
		return False
def is_coin(p,q):
	if Matrix[p][q]=="C" :
		return True
	else:
		return False


def coins():
	global coins_counter
	coins_counter=random.randint(1,2)
	for i in xrange(coins_counter):
		p=random.randint(1,33)
		q=random.randint(1,45)
		Matrix[p][q] = 'C'

class person(object):
	def __init__(self,x,y):
		self.x=x
		self.y=y

	def move_right(self):
		Matrix[self.x][self.y+1]=Matrix[self.x][self.y]
		Matrix[self.x][self.y]='.'
		self.y=self.y+1

	def move_left(self):
		Matrix[self.x][self.y-1]=Matrix[self.x][self.y]
		Matrix[self.x][self.y]='.'
		self.y=self.y-1

	def move_top(self):
		Matrix[self.x-1][self.y]=Matrix[self.x][self.y]
		Matrix[self.x][self.y]='.'
		self.x=self.x-1

	def move_bottom(self):
		Matrix[self.x+1][self.y]=Matrix[self.x][self.y]
		Matrix[self.x][self.y]='.'
		self.x=self.x+1

class pacman(person):
	def __init__(self,x,y,score):
		self.x=x
		self.y=y
		self.score=score

	def collect_coin(self,x,y):
		if Matrix[x][y] == 'C':
			#global score
			self.score+=10
			global coins_counter
			coins_counter-=1

	def mover(self, move):
		self.move = move
		return self.move


#def move(self):


class ghost(person):
	def __init__(self,x,y):
		self.x=x
		self.y=y

	def mover(self,move):
		x=random.randint(1,4)
		self.move = x
		return self.move



pac=pacman(17,25,score)


def make_ghost():
	global ghost_count
	ghost_count=random.randint(10,15)
	for i in xrange(ghost_count):
		ghost_x[i]=random.randint(1,34)
		ghost_y[i]=random.randint(1,48)
		Matrix[ghost_x[i]][ghost_y[i]] = 'G'

		ghost_instance[i] = ghost(ghost_x[i],ghost_y[i])


make_ghost()
coins()

flag1=0
def printf():
	global flag,flag1
	print coins_counter
	if coins_counter == 0:
		print "YOU WON"
		print "New Game Starting"

		flag =0
		flag1 = 1
	else:
		for i in xrange(36):
			print
			for j in xrange(50):
				if Matrix[i][j] == "P":
					print bcolors.GREEN + Matrix[i][j] + bcolors.ENDC,
				elif Matrix[i][j] == "G":
					print bcolors.FAIL + Matrix[i][j] + bcolors.ENDC,
				elif Matrix[i][j]=="C":
					print bcolors.YELLOW + Matrix[i][j] + bcolors.ENDC,
					
				else:
					print Matrix[i][j],		

		print
		#global score
		global pac
		print "Score :", pac.score		
		global move
		move = raw_input("Enter Move : ")
		
		if move != 'q' :

			global p,q,r,s
			where_move = pac.mover(move)

			if where_move is 'd' :
				if check_wall(pac.x,pac.y + 1) is False:
					if check_ghost(pac.x,pac.y + 1) is False:
						
						pac.collect_coin(pac.x,pac.y + 1)
						pac.move_right()
						
					else:
						flag=1
				else:
					if q!=0 | r!=0 | s!= 0 :
							#print "fuck"
						p=0
					p = p + 1
					if p == 3:
						 u =pac.x
						 v = pac.y
						 Matrix[u][v+1] = "."
						 p=0


			if where_move is 'a' :
				if check_wall(pac.x,pac.y - 1) is False:
					if check_ghost(pac.x,pac.y - 1) is False:
						
						pac.collect_coin(pac.x,pac.y - 1)
						pac.move_left()
						
					else:
						flag=1
				else:
					if p!=0 | r!=0 | s!= 0 :
							#print "fuck"
						q=0
					q = q + 1 
					if q == 3:
						 u =pac.x
						 v = pac.y
						 Matrix[u][v-1] = "."
						 q=0

        		if where_move is 'w' :
				if check_wall(pac.x - 1,pac.y ) is False:
					if check_ghost(pac.x - 1,pac.y) is False:
						
						pac.collect_coin(pac.x - 1,pac.y )
						pac.move_top()
						
					else:
						flag=1
				else:
					if q!=0 | p!=0 | s!= 0 :
							#print "fuck"
						r=0
					r  = r + 1
					if r == 3:
						 u =pac.x
						 v = pac.y
						 Matrix[u - 1][v] = "."
						 r=0

        		if where_move is 's' :
				if check_wall(pac.x + 1,pac.y) is False:
					if check_ghost(pac.x + 1,pac.y) is False:
						
						pac.collect_coin(pac.x + 1,pac.y)
						pac.move_bottom()
						
					else:
						flag=1
				else:
					if q!=0 | r!=0 | p!= 0 :
							#print "fuck"
						s=0
					s = s + 1
					if s == 3:
						 u =pac.x
						 v = pac.y
						 Matrix[u+1][v] = "."
						 s=0

     
				
			global ghost_count
			for i in xrange(ghost_count) :
				where_move = ghost_instance[i].mover(move)
			
				
				if where_move is 1 and check_wall(ghost_instance[i].x,ghost_instance[i].y + 1) is False: 
					if check_pacman(ghost_instance[i].x,ghost_instance[i].y + 1) is False: 
						if check_ghost(ghost_instance[i].x,ghost_instance[i].y + 1) is False and is_coin(ghost_instance[i].x,ghost_instance[i].y + 1) is False:
							ghost_instance[i].move_right()
					else:
						ghost_instance[i].move_right()
						flag=1

				elif where_move is 2 and check_wall(ghost_instance[i].x,ghost_instance[i].y - 1) is False:
					if check_pacman(ghost_instance[i].x,ghost_instance[i].y - 1) is False  and is_coin(ghost_instance[i].x,ghost_instance[i].y - 1) is False:
						if check_ghost(ghost_instance[i].x,ghost_instance[i].y - 1) is False:
							ghost_instance[i].move_left()
					else:
						ghost_instance[i].move_left()
						flag=1
				
				elif where_move is 3 and check_wall(ghost_instance[i].x - 1,ghost_instance[i].y) is False:
					if check_pacman(ghost_instance[i].x - 1,ghost_instance[i].y) is False  and is_coin(ghost_instance[i].x - 1,ghost_instance[i].y) is False:
						if check_ghost(ghost_instance[i].x - 1,ghost_instance[i].y) is False:
							ghost_instance[i].move_top()
					else:
						flag=1
				
				elif where_move is 4 and check_wall(ghost_instance[i].x + 1,ghost_instance[i].y) is False:
					if check_pacman(ghost_instance[i].x + 1,ghost_instance[i].y) is False  and is_coin(ghost_instance[i].x + 1,ghost_instance[i].y) is False:
						if check_ghost(ghost_instance[i].x + 1,ghost_instance[i].y) is False:
							ghost_instance[i].move_bottom()
					else:
						flag=1

		else:
			flag=1
		if flag is 0:		
			printf()

if flag is 0:
	printf()
#if move is not 'q':
#maze(

def again():
	global flag1, flag
	flag1=0
	for i in xrange(35) :
	    
	    for j in xrange(50) :
	        
	        Matrix[i][j]='.'

	for i in xrange(50):
		Matrix[0][i]='X'
		Matrix[35][i]='X'
		Matrix[i][0]='X'
		Matrix[i][49]='X'
	global flag,score,pac

	flag = 0
	maze()
	
	make_ghost()
	make_pac()
	coins()
	global score
	score = pac.score
	pac=pacman(17,25,score)
	printf()

while (1):
	if flag is 1:
		break
	if flag1 is 1:
		again()


