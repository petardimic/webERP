import random
from random import randrange

Matrix = [[0 for x in xrange(100)] for x in xrange(100)]

for i in xrange(35) :
    
    for j in xrange(50) :
        
        Matrix[i][j]='.'

for i in xrange(50):
	Matrix[0][i]='X'
	Matrix[35][i]='X'
	Matrix[i][0]='X'
	Matrix[i][49]='X'

def fun1():
	x = random.randint(0,44)
	y = random.randint(0,28)
	for i in range(x,x+8):
		Matrix[y][i] = 'X'

def fun2():
	x = random.randint(0,28)
	y = random.randint(0,44)
	for i in range(x,x+8):
		Matrix[i][y] = 'X'

def fun3():
	x = random.randint(0,28)
	y = random.randint(0,44)
	for i in range(x,x+8):
		Matrix[y][i] = 'X'
	for i in xrange(y,y+7):
		Matrix[i][x] = 'X'

def fun4():
	x = random.randint(0,28)
	y = random.randint(0,44)
	for i in range(x,x+8):
		Matrix[y][i] = 'X'
	for i in xrange(y,y+7):
		Matrix[i][x+7] = 'X'

def fun5():
	x = random.randint(0,25)
	y = random.randint(0,44)
	a1=x
	a2=y
	for i in range(4):
		Matrix[a1][a2]='X'
		a1=a1+1
		a2=a2+1
	a1=x
	a2=y
	for i in range(4):
		Matrix[a1][a2]='X'
		a1=a1-1
		a2=a2+1
	a1=x
	a2=y
	for i in range(4):
		Matrix[a1][a2]='X'
		a1=a1-1
		a2=a2-1
	a1=x
	a2=y
	for i in range(4):
		Matrix[a1][a2]='X'
		a1=a1+1
		a2=a2-1

def fun6():
	x = random.randint(0,47)
	y = random.randint(0,28)
	for i in range(x,x+8):
		Matrix[y][i] = 'X'
	for i in xrange(y,y+7):
		Matrix[i][x+7] = 'X'
	for i in xrange(y,y+7):
		Matrix[i][x]

def fun7():
	y=0
	x = random.randint(0,44)
	for i in range(random.randint(0,7)):
		Matrix[i][x] = 'X'
	for i in range(random.randint(0,10)):
		Matrix[i][x+1]='X'
	for i in range(random.randint(0,7)):
		Matrix[i][x+2]='X'
	
def fun8():
	y=0
	x = random.randint(0,35)
	for i in range(random.randint(0,7)):
		Matrix[x][i] = 'X'
	for i in range(random.randint(0,10)):
		Matrix[x+1][i]='X'
	for i in range(random.randint(0,7)):
		Matrix[x+2][i]='X'

def fun9():
	y=49
	x = random.randint(0,35)
	for i in range(random.randint(0,7)):
		Matrix[x][i] = 'X'
	for i in range(random.randint(0,10)):
		Matrix[x+1][i]='X'
	for i in range(random.randint(0,7)):
		Matrix[x+2][i]='X'

def maze():
	fun1()
	fun1()
	fun2()
	fun2()
	fun3()
	fun3()
	fun4()
	fun5()
	fun5()
	fun6()
	fun7()
	fun7()
	fun8()
	fun8()

