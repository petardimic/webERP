import shutil
import sys

import os



def ls():
	if len(y) is 1:
		for i in os.listdir("./"):
			print i

	else:
		for k in xrange(1,len(y)):

			if os.path.isdir(y[k]):
				if len(x) > 2:
				#if y[1]:
					for i in os.listdir(y[k]):
						if i[0] is not '.':
							if os.path.isfile(y[k] + i):
								print i
							else:
								print '\033[94m' + i + '\033[0m'
				else:
					for i in os.listdir("."):
						if i[0] is not '.':
							if os.path.isfile(i):
								print i
							else:
								print '\033[94m' + i + '\033[0m'
			else:
				print y[k]

def cp():
	src = y[1]
	dstn = y[2]
	
	shutil.copy(src,dstn)		

def cp_tree():
	try:
	    src = y[2]
    	    dstn = y[3]
	    if os.path.isdir(dstn):
	    	dstn1=dstn + "/" + src
		shutil.copytree(src,dstn1)
	    else:
		shutil.copytree(y[2],y[3])
	except:
		IndexError
		print "cannot copy"

def mv():
	try:
		if os.path.isdir(y[len(y) - 1]):
		
			for k in xrange(1,len(y)):

				src = y[k]
		        	dstn = y[ len(y) -1 ]
				shutil.move(src,dstn)

		else:
			print y[len(y) - 1] + " is not a directory"
	except :
		OSError
		print "cannot move"

	

def rm():
	try:
	    for k in xrange(1,len(y)):

	        path = y[k]
	        os.remove(path)
	except:
	    OSError
	    print "cannot remove"

def rmtree():
	try:
	    for k in xrange(2,len(y)):
	        shutil.rmtree(y[k])
	except:
	    OSError
            print "cannot remove"



def dirstr(path):
	for dirpath , dirname , files in os.walk (path):
		depth = dirpath.count("/") - 1
		indent = " " * 2 * depth
		
#print indent + "|"
		dir_str = os.path.abspath(dirpath)
		folder = os.path.basename(dir_str)
		print "|  " * (depth + 2) + " "
		for i in xrange(depth+1):
			print "| ",
		print "#----------" + "folder name : " +  folder + "----------#"
		file_indent = " " * 2 * (depth+1)

		listx = os.listdir(dirpath)
		if not listx:
		    print 
		    print "              " + "(EMPTY FOLDER)"
		else:
		    for f in files:
		        print "|  " * (depth + 2) + " "
			
			print "|  " * (depth + 1) + "#_" + f


import os
import time
from stat import *
import pwd
import grp
from pwd import getpwuid

def ls_l():
	ans=""
	p ="a"
	if len(y[1]) is 2:
		a=os.listdir(".")
        else:
		a = os.listdir(y[2])
	for i in a:
	  if i[0] is not '.':
	    if os.path.isdir(i):
        	ans = "d"
       	    else:
        	ans = "-"
	    x = os.stat(i)[ST_MODE]
	    x = oct(x)
	    z = x[-3:]
	    for j in range(0,3):
	        if z[j] is '7':
		    p = "rwx"
	        elif z[j] is '6':
		    p = "rw-"
		elif z[j] is '4':
		    p = "r--"
		ans = ans + p
	    
	    x = os.stat(i)[ST_NLINK]
	    ans = ans + "  " + str(x)
	    stat_info = os.stat(i)
	    uid = stat_info.st_uid
	    gid = stat_info.st_gid

	    user = pwd.getpwuid(uid)[0]
	    group = grp.getgrgid(gid)[0]
	    ans = ans + "  " + user + "  " + group

	    x = os.stat(i)[ST_SIZE]
	    ans = ans + "  " + str(x)

	    x= time.ctime(os.stat(i)[ST_MTIME])
	    x = x[4:-8]
	    ans = ans + "  " + str(x) + "  " + i
		    
	    print ans


x = raw_input("enter command:")
y=[]
x=(' ').join(x.split())
y = x.split(' ')
query = y[0]
if query == 'ls':
	if len(y) > 1:
		if y[1] == "-l":
			ls_l()
		else :
			ls()
	else:
		ls()

elif query == 'cp' :
	try:
		if y[1]=='-r':
	   		cp_tree()
		else:
  			cp()
	except:
		IndexError
		print "can't copy"

elif query == "mv":
	mv()

elif query == "rm":
	if y[1]=='-r':
	    rmtree()
	else: 
	    rm()
elif query == "dirstr" :
	dirstr(".")
else :
	print "invalid command"




