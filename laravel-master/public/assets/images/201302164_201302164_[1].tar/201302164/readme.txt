Q1

		In a.py (pacman game) I implemented OOPS principle as follows:

		inheritance: class pacman and class ghost both are inherited from class person.
		modularity : I've made a module named maze.py which is imported in a.py, it create the whole maze.
		encapsulation: Encapsulation is the packing of data and functions into a single component which I did using 'classes'
		polymorphism: a function 'mover' is defined in both classes ghost as well as pacman. in pacman functionality of mover function is that pacman can move i a paticular direction as per as input whereas 'mover' in ghost class has functionality that ghost can mov in any direction.

		special features:
		    when pacman is beside the wall, on pressing the same key 4 times ,then that brick is destroyed.

		ghost is of red colour, pacman is of green and coins are of yellow colour.

		every time game is restarted , whole maze is randomly formed.

		multiple ghost.

		P.S. : run ./a.py in fullscreen mode

Q2
		List of commands
	    
	    ls : 	multiple arguments(files and dir) can be given.
	    mv : 	multiple files can be moved in a directory. A file can be renamed
	    rm :	multiple files can be removed.
	    rm -r :     multiple directories can be removed.
	    cp : 	copies a file 
	    cp -r : 	copies a directory
	    dirstr : 	prints tree structure of present working directory
	    ls -l : 	lists given directory in longlist form.

	Extra implemented commands:
	    cd :   changes current working dir
	    mkdir: creates a dir
	    touch: creates an empty file



